
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="text-center">
            <h2 class="font-weight-bold"> <?php echo e($project->sap_id); ?></h2>
        </div>
    </div>

    <div class="row mx-auto">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>SAP id:</strong>
                <?php echo e($project->sap_id); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Hostname:</strong>
                <?php echo e($project->hostname); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>LoopBack:</strong>
                <?php echo e($project->loopback); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Mac address:</strong>
                <?php echo e($project->mac_address); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Date Created:</strong>
                <?php echo e(date_format($project->created_at, 'jS M Y')); ?>

            </div>
        </div>
    </div>
    
<?php /**PATH C:\xampp\htdocs\routerapp\resources\views/projects/show.blade.php ENDPATH**/ ?>