
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="text-center font-weight-bolder">
                <h2 class="font-weight-bold">Edit Project</h2>
            </div>
            
        </div>
    </div>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('projects.update', $project->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>SAP Id:</strong>
                    <input type="text" name="name" value="<?php echo e($project->sap_id); ?>" class="form-control" placeholder="Name">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Hostname:</strong>
                    <textarea class="form-control" style="height:50px" name="introduction"
                        placeholder="Introduction"><?php echo e($project->hostname); ?></textarea>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>loopback:</strong>
                    <input type="text" name="location" class="form-control" placeholder="<?php echo e($project->location); ?>"
                        value="<?php echo e($project->loopback); ?>">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Macaddress:</strong>
                    <input type="text" name="cost" class="form-control" placeholder="<?php echo e($project->cost); ?>"
                        value="<?php echo e($project->mac_address); ?>">
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <a class="btn btn-primary" href="" data-dismiss="modal"> Cancel</a>


                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>

    </form>

<?php /**PATH C:\xampp\htdocs\routerapp\resources\views/projects/edit.blade.php ENDPATH**/ ?>