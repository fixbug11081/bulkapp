@extends('layouts.app')

@section('content')

<style>

tr:hover, tr.hover, tr.matching {
    background: grey;
}
tr:hover, tr.hover, tr.validate {
    background: green;
}
tr:hover, tr.hover, td.click, input.unmatching {
    background: red;
}

</style>

<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Router details</h2>
        </div>
        <div class="d-flex flex-row-reverse flex-column">
            <div class="d-flex">

            
            <button   id="download"  class="btn btn-info" style="margin-left: -60px" title="Import Project">
                    Download File<i class="fas fa-2x"></i> </button>
             &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                <a class="btn btn-success text-light mr-5" data-toggle="modal" id="mediumButton" data-target="#mediumModal" data-attr="{{ route('projects.create') }}" title="Create a project">
                    <i class="fas fa-plus-circle fa-2x"></i>
                </a>
              

                <form action="{{ route('importProject') }}" method="POST" enctype="multipart/form-data" class="d-flex">
                    @csrf
                    <input type="file" name="file" style="height: 30px !important">

                    <button class="btn btn-info" style="margin-left: -60px" title="Import Project">
                        <i class="fas fa-cloud-upload-alt fa-2x"></i> </button>
                </form>
            
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
    <div class="alert alert-success">
        <p>{{ $message }}</p>
    </div>
    @endif

    <table class="table table-bordered table-responsive-lg table-hover" id="routertable">
        <thead class="thead-dark">
            <tr>
                <th scope="col" >No</th>
                <th scope="col" >SAP id</th>
                <th scope="col" width="30%" >Host Name</th>
                <th scope="col">Loopback</th>
                <th scope="col" >Mac Address</th>
                <th scope="col">Date Created</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            
            @foreach ($projects as $project)
            <tr>
                <td scope="row">{{ ++$i }}</td>
                <td class="sap_id"><input  type="text" value={{ $project->sap_id}}  ></td>
                <td class="hostname"><input  type="text" value={{ $project->hostname}} ></td>
                <td class="loopback"><input  type="text" value={{ $project->loopback}} ></td>
                <td class="mac_address"><input  type="text" value={{ $project->mac_address}} ></td>
               <!-- <td>{{ $project->cost }}</td>-->
                <td>{{ date_format($project->created_at, 'jS M Y') }}</td>
                <td>

                        <button type="submit" id="save" value="Save" title="save" style="border: none; background-color:transparent;">
                            Save
                        </button>
                

                    <form action="{{ route('projects.destroy', $project->id) }}" method="POST">
                     
                    
                    <a data-toggle="modal" id="smallButton" data-target="#smallModal" data-attr="{{ route('projects.show', $project->id) }}" title="show">
                            <i class="fas fa-eye text-success  fa-lg"></i>
                        </a>

                        <a class="text-secondary" data-toggle="modal" id="mediumButton" data-target="#mediumModal" data-attr="{{ route('projects.edit', $project->id) }}">
                            <i class="fas fa-edit text-gray-300"></i>
                        </a>
                        @csrf
                        @method('DELETE')
                     

                        <button type="submit" title="delete" style="border: none; background-color:transparent;">
                            <i class="fas fa-trash fa-lg text-danger"></i>
                        </button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>

   

    <!-- small modal -->
    <div class="modal fade" id="smallModal" tabindex="-1" role="dialog" aria-labelledby="smallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="smallBody">
                    <div>
                        <!-- the result to be displayed apply here -->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- medium modal -->
    <div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="mediumBody">
                    <div>
                        <!-- the result to be displayed apply here -->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
        // display a modal (small modal)
        $(document).on('click', '#smallButton', function(event) {
            event.preventDefault();
            let href = $(this).attr('data-attr');
            $.ajax({
                url: href
                , beforeSend: function() {
                    $('#loader').show();
                },
                // return the result
                success: function(result) {
                    $('#smallModal').modal("show");
                    $('#smallBody').html(result).show();
                }
                , complete: function() {
                    $('#loader').hide();
                }
                , error: function(jqXHR, testStatus, error) {
                    console.log(error);
                    alert("Page " + href + " cannot open. Error:" + error);
                    $('#loader').hide();
                }
                , timeout: 8000
                
            })
           
        });
        $(document).ready(function(){    

            // Mouse over event handler
            $('table').on('mouseover', 'td', function() {
                // Store the hovered cell's text in a variable
                //var textToMatch = $(this).text();
                var sap_id =$("td").eq(1).find('input').val();
                var hostname =$("td").eq(2).find('input').val();
                var mac_address = $("td").eq(4).find('input').val();
                //alert(sap_id);
                // Loop through every `td` element
                $('td').each(function() {
                    // Pull selected `td` element's text
                    //var text = $(this).text();
                    var sap_idtomatch=$("td").eq(1).find('input').val();
                   // alert(sap_idtomatch);
                    var hostnametomatch =$("td").eq(2).find('input').val();
                    var mac_addresstomatch = $("td").eq(4).find('input').val();
                  

                    // Compare this with initial text and add matching class if it matches
                    if((sap_id == sap_idtomatch)&&(hostname == hostnametomatch)&&(mac_address == mac_addresstomatch))
                        $(this).parent().addClass('matching');
                        if((sap_id != sap_idtomatch)&&(hostname != hostnametomatch)&&(mac_address != mac_addresstomatch))
                      $(this).parent().addClass('unmatching');    
                
                });

            });});
            // Mouse out event handler
            // This simply removes the matching styling
        $('table').on('mouseout', 'td', function() {
                $('.matching').removeClass('matching');
            });       
   
        $('table').on('click', 'td', function() {            
            $("td").on('click', function(){
               var  cond = $(this).hasClass("hostname");
                if(cond == true){
                    var hostname =$("td").eq(2).find('input').val();                   
                    if(hostname.length != 14){
                        alert("Invalid hostname length");
                    $(this).children("input").addClass('unmatching'); 
                    }   
                } 
                var cond1 = $(this).hasClass("sap_id");
                if(cond1 == true){
                    var sap_id =$("td").eq(1).find('input').val();                   
                    if(sap_id.length != 18){
                        alert("Invalid sap_id length");
                    $(this).children("input").addClass('unmatching');   
                    } 
                } 
                
                var cond2 = $(this).hasClass("mac_address");
                if(cond2 == true){
                    var mac_address =$("td").eq(4).find('input').val();                   
                    if(mac_address.length != 17){
                    alert("Invalid mac_aaddress length");
                    $(this).children("input").addClass('unmatching');
                    }    
                }
        });});
           
     
        // display a modal (medium modal)
        $(document).on('click', '#mediumButton', function(event) {
            event.preventDefault();
            let href = $(this).attr('data-attr');
            $.ajax({
                url: href
                , beforeSend: function() {
                    $('#loader').show();
                },
                // return the result
                success: function(result) {
                    $('#mediumModal').modal("show");
                    $('#mediumBody').html(result).show();
                }
                , complete: function() {
                    $('#loader').hide();
                }
                , error: function(jqXHR, testStatus, error) {
                    console.log(error);
                    alert("Page " + href + " cannot open. Error:" + error);
                    $('#loader').hide();
                }
                , timeout: 8000
            })
            
        });
    $("#save").on('click',function(){
        sap_id = $("input[name=sap_id]").val();
        hostname = $("input[name=hostname]").val();
        loopback = $("input[name=loopback]").val();
        mac_address = $("input[name=mac_address]").val();
            $.ajax({
                type: "POST",
                url: {{ route('projects.edit', $project->id) }} ,
                data: {sap_id: sap_id, hostname: hostname, loopback: loopback, mac_address:mac_address},
                success: function(response){
                   alert("Record updated");
                }
            });
        });
    </script>;/
    @endsection
